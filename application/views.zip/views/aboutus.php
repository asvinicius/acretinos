<head>
    <title>Sobre a liga</title>
</head>
<section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="inner-heading">
                    <h2>A Liga</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="content">
    <div class="container">
        <div class="row">
            <div class="span12">
                <h2>O nascimento da <strong>Liga Acretinos</strong></h2>
				<img src="<?= base_url('assets/img/logotipo.png'); ?>" alt="" width="300px" class="align-left" />
                <p>
                    O início da Liga Acretinos se deu no ano de 2014, a partir da ideia dos amigos Jorge e Willian de ter uma liga para disputar
					entre amigos.
                </p>
                <p>
                    A ideia acabou evoluindo e a Liga Acretinos passou a ser apostada, para existir um lucro além do divertimento. Em 2016 ela começou 
					a tomar uma forma mais organizada, apesar de ainda contar com poucos times.
                </p>
                <p>
					A Liga Acretinos tomou uma conotação mais séria a partir de 2018, tendo mais participantes do que simplesmente o ciclo de amizade
					dos criadores da liga. Já gozando de um reconhecimento por sempre tratar as transações com seriedade, foi ganhando a admiração e o 
					respeito dos participantes. Foi também neste ano que teve início o Bolão Acretinos, uma disputa tiro-curto por rodada que 
					ganhou a simpatia dos participantes da liga, se tornando, no ano seguinte, uma das competições mais importantes da liga.
                </p>
                <p>
                    Também em 2019, a Liga Acretinos testou e idealizou outros tipos de competições e tem tudo para se tornar, ja em 2020, uma das melhores
					ligas apostadas de cartola fc da região.
                </p>
            </div>
        </div>
    </div>
</section>