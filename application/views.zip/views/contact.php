<head>
    <title>Contato</title>
</head>
<section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="inner-heading">
                    <h2>Contato</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="content">
    <div class="container">
        <div class="row">
			<div class="span12">
				<h4>Fale com um de nossos <strong>Administradores</strong></h4>
			</div>
			<div class="span3">
				<div class="pricing-box-alt">
					<div class="pricing-heading">
						<h3><strong>Dealesson</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>68 99926-4852</h6>
					</div>
					<div class="pricing-action">
						<a href="https://api.whatsapp.com/send?phone=5568999264852&text=Olá, Dealesson. Estou entrando em contato a partir do site da Liga Acretinos." class="btn btn-medium btn-theme" target="_blank"><i class="icon-comment" ></i> Whatsapp</a>
					</div>
				</div>
			</div>
			<div class="span3">
				<div class="pricing-box-alt">
					<div class="pricing-heading">
						<h3><strong>Matias</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>68 98405-1567</h6>
					</div>
					<div class="pricing-action">
						<a href="https://api.whatsapp.com/send?phone=5568984051567&text=Olá, Matias. Estou entrando em contato a partir do site da Liga Acretinos." class="btn btn-medium btn-theme" target="_blank"><i class="icon-comment" ></i> Whatsapp</a>
					</div>
				</div>
			</div>
			<div class="span3">
				<div class="pricing-box-alt">
					<div class="pricing-heading">
						<h3><strong>Vinícius</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>68 99203-8448</h6>
					</div>
					<div class="pricing-action">
						<a href="https://api.whatsapp.com/send?phone=5568992038448&text=Olá, Vinícius. Estou entrando em contato a partir do site da Liga Acretinos." class="btn btn-medium btn-theme" target="_blank"><i class="icon-comment" ></i> Whatsapp</a>
					</div>
				</div>
			</div>
			<div class="span3">
				<div class="pricing-box-alt">
					<div class="pricing-heading">
						<h3><strong>Wisley</strong></h3>
					</div>
					<div class="pricing-terms">
						<h6>68 99967-8391</h6>
					</div>
					<div class="pricing-action">
						<a href="https://api.whatsapp.com/send?phone=5568999678391&text=Olá, Wisley. Estou entrando em contato a partir do site da Liga Acretinos." class="btn btn-medium btn-theme" target="_blank"><i class="icon-comment" ></i> Whatsapp</a>
					</div>
				</div>
			</div>
        </div>
    </div>
</section>