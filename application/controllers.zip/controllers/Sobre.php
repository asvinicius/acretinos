<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Sobre extends CI_Controller {

    public function index(){        
        $this->load->view('template/header');
        $this->load->view('aboutus');
        $this->load->view('template/footer');
    }
}